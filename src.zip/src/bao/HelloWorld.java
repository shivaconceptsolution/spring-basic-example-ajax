package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorld {
    @RequestMapping("/abc")
	public String displayHello()
	{
		return "hello";
	}
    @RequestMapping("/welcome")
   	public String displayWelcome()
   	{
   		return "welcome";
   	}
}
