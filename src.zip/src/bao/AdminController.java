package bao;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dao.Login;
import dao.Register;

@Controller
public class AdminController {
	@RequestMapping("admin")
	public ModelAndView regLoad()
	{
		return new ModelAndView("adminlogin","command",new Login());
	}
	@RequestMapping(value = "adminloginlogic", method = RequestMethod.POST)
	public ModelAndView loginlogic(@ModelAttribute("SpringbasicExample")Login obj,HttpServletRequest request,HttpServletResponse response) {

		Configuration cfg = new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session s = sf.openSession();
	    Query q = s.createQuery("from Login r where r.username=? and r.password=?");
	    q.setString(0,obj.getUsername());
	    q.setString(1,obj.getPassword());
	    List lst= q.list();
	    String res="";
	    if(lst.size()>0)
	    {
	    	if(request.getParameter("chk")!=null)
	    	{
	    		Cookie c = new Cookie("cuid",obj.getUsername());
	    		response.addCookie(c);
	    		c.setMaxAge(10000);
	    		Cookie c1 = new Cookie("cpass",obj.getPassword());
	    		response.addCookie(c1);
	    		c1.setMaxAge(10000);
	    	}
	    	HttpSession session= request.getSession();
	    	session.setAttribute("adminid",obj.getUsername());
	    	
	    	return new ModelAndView("redirect:dashboard.do");
	    }
	    else
	    {
	    	res = "Invalid userid and password";
	    	return new ModelAndView("loginresult","key",res);
	    }
	    
	}
	@RequestMapping("logout")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response)
	{
		HttpSession session= request.getSession();
    	session.removeAttribute("adminid");
    	session.invalidate();
		return new ModelAndView("redirect:admin.do");
	}
}
