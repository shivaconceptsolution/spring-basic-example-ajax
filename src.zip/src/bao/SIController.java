package bao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.*;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SIController {
	  @RequestMapping("/si")
      public ModelAndView siload() {
        return new ModelAndView("siview", "command", new SI());
       }
	  
		@RequestMapping(value = "/silogic", method = RequestMethod.POST)
	      public ModelAndView silogic(@ModelAttribute("SpringbasicExample")SI obj, ModelMap model) {
	     // model.addAttribute("p", obj.getP());
	     // model.addAttribute("r", obj.getR());
	     // model.addAttribute("t", obj.getT());
	     // float r = model.get("p")*model.get("r")*model.get("t");
	      Configuration cfg = new Configuration();
	      cfg.configure("hibernate.cfg.xml");
	      SessionFactory sf = cfg.buildSessionFactory();
	      Session s = sf.openSession();
	      Transaction tx = s.beginTransaction();
	      SI si = new SI();
	      si.setP(obj.getP());
	      si.setR(obj.getR());
	      si.setT(obj.getT());
	      s.save(si);
	      tx.commit();
	      float r = (obj.getP()*obj.getR()*obj.getT())/100;
	      return new ModelAndView("siresult","res",r);
	       }    
}
