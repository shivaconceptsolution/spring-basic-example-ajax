package bao;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdditionExample {

	@RequestMapping("/add")
	public String loadForm()
	{
		return "add";
	}
	
	@RequestMapping("/addlogic")
	public ModelAndView addLogic(HttpServletRequest request, HttpServletResponse response)
	{
		int a = Integer.parseInt(request.getParameter("txtnum1"));
		int b = Integer.parseInt(request.getParameter("txtnum2"));
		Hashtable<String, Integer> ht = new Hashtable<>();
		ht.put("num1",a);
		ht.put("num2",b);
		
		Set<Map.Entry<String,Integer>> se = ht.entrySet();
		int sum=0;
		for(Map.Entry<String, Integer> me:se)
		{
			sum = sum+me.getValue();
		}
		int c= sum;
		return new ModelAndView("add","key","result is "+c);
	}
	
}
